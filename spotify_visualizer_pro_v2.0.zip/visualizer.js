(function () {
  'use strict';

  const validKeys = [
    "ZP-4321-001", "ZP-4321-002", "ZP-4321-003", "ZP-4321-004", "ZP-4321-005"
  ];
  const userKey = localStorage.getItem("sv_pro_key");

  if (!validKeys.includes(userKey)) {
    alert("❌ Invalid or missing license key. Please enter your key to continue.");
    const newKey = prompt("Enter your Spotify Visualizer Pro license key:");
    if (!validKeys.includes(newKey)) {
      alert("❌ Access Denied. Please purchase a license from Gumroad.");
      return;
    } else {
      localStorage.setItem("sv_pro_key", newKey);
    }
  }

  console.log("🎵 Pro visualizer active");
})();