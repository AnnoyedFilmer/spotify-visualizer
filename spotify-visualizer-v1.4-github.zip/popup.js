
const validKeys = ["PRO-XO0O-BFN4-HYQL", "PRO-SLW0-NT2P-NOSN", "PRO-71F7-V14I-QBBW", "PRO-O2QM-A39L-7XI1", "PRO-SRFX-5HSK-2Z9X", "PRO-P23S-252A-WA4V", "PRO-WCZO-04M1-6BKQ", "PRO-EY22-9V48-FCS5", "PRO-MLJL-1MW9-9HEU", "PRO-MZNQ-LOLT-DTHN", "PRO-TZ0R-ZW0U-IN9Y", "PRO-MF0Y-F3LR-KM5H", "PRO-E517-YQ5B-FR95", "PRO-S1V1-PEJC-H7UZ", "PRO-EZ6T-TGGE-45OL", "PRO-U92R-J66V-KBRP", "PRO-FFRT-SR67-QTAI", "PRO-KESO-RXFQ-9O9F", "PRO-T8RB-P36J-29UX", "PRO-X8UY-RV32-B1ME", "PRO-EFLC-C0YL-WOO2", "PRO-O1YJ-TLOS-FJF7", "PRO-1Z5Z-OON9-HH36", "PRO-T7GP-ZRYI-GW8X", "PRO-4U0C-ARGD-4F2I", "PRO-C79B-4C5B-VVVR", "PRO-V4QB-HKBO-31NV", "PRO-6SH0-AVLP-R0M2", "PRO-RS6S-J7Z1-4ZDM", "PRO-3WCC-TWUY-8NCE", "PRO-8POD-C8J8-9V5O", "PRO-JYSP-K817-0NOF", "PRO-I8MZ-K2W7-5J6A", "PRO-LJWY-6RML-CO70", "PRO-Q997-FL86-ZOFQ", "PRO-78W8-3U0B-3EK9", "PRO-I8GG-KUEG-R3NS", "PRO-QWGS-QLFO-X1G6", "PRO-W9KR-DP9W-MBEO", "PRO-791X-5LCI-4ADU", "PRO-JPQ6-FDKK-TLEN", "PRO-O38G-ZZYL-H9F9", "PRO-ALH7-J3RA-BDYL", "PRO-Q6AR-N8LM-FXVQ", "PRO-IKRZ-M3MC-3AU4", "PRO-0XV5-54TS-K6P2", "PRO-EFTU-SNO0-WJ7D", "PRO-Q8B4-WOX9-73JR", "PRO-UIQI-6VSO-RR14", "PRO-6J7K-3YW8-ZCOG"];

document.getElementById("submitKey").addEventListener("click", () => {
  const enteredKey = document.getElementById("licenseInput").value.trim().toUpperCase();
  const isValid = validKeys.includes(enteredKey);

  if (isValid) {
    chrome.storage.sync.set({ isPro: true }, () => {
      document.getElementById("statusMsg").textContent = "✅ Pro activated!";
    });
  } else {
    document.getElementById("statusMsg").textContent = "❌ Invalid key.";
  }
});
