(async () => {
  const result = await chrome.storage.sync.get("isPro");
  const isPro = result.isPro;

  if (document.getElementById("visualizer-bars")) return;

  const container = document.createElement("div");
  container.id = "visualizer-bars";
  container.style.position = "fixed";
  container.style.bottom = "75px";
  container.style.left = "0";
  container.style.width = "100%";
  container.style.height = "50px";
  container.style.display = "flex";
  container.style.justifyContent = "center";
  container.style.zIndex = "9999";
  container.style.pointerEvents = "none";

  const style = document.createElement("style");
  let keyframeCSS = "";

  for (let i = 0; i < 48; i++) {
    const bar = document.createElement("div");
    bar.style.width = "6px";
    bar.style.height = "50px";
    bar.style.margin = "0 7.5px";
    bar.style.borderRadius = "4px";

    if (isPro) {
      bar.style.background = "rgb(30, 215, 96)";
      bar.style.animation = "pulse 1s ease-in-out infinite";
      bar.style.animationDelay = `${(i % 6) * 0.15}s`;
      keyframeCSS = `@keyframes pulse {
        0%, 100% { transform: scaleY(1); }
        50% { transform: scaleY(1.8); }
      }`;
      container.style.backdropFilter = "blur(10px)";
      container.style.boxShadow = "0 0 10px rgba(255,255,255,0.3)";
    } else {
      bar.style.background = "white";
      bar.style.animation = "bounce 1s ease-in-out infinite";
      bar.style.animationDelay = `${Math.random().toFixed(2)}s`;
      keyframeCSS = `@keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-20px); }
      }`;
    }

    container.appendChild(bar);
  }

  console.log("[Visualizer] Injecting visualizer bars.");
  style.textContent = keyframeCSS;
  document.body.appendChild(style);
  document.body.appendChild(container);
})();
